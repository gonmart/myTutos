require( "coffee-script" );

module.exports = require( "./lib/index.coffee" );
