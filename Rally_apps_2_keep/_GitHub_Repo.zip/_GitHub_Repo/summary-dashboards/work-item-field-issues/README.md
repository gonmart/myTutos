#Work Item Field Issues

6/29/2015:
Added feature validation logic:
If a feature is a program level risk (No stories and no parent), then it is flagged as such and other fields are not checked.
More intelligence in feature date validation, providing more detail based on the planned start and end dates and how they correlate with the actual start and end dates.

