describe("Example test set", function() {
    it("should have written tests",function(){
        //create mock data
        //create calculator

        expect(false).toBe(true);

        //create chart
    });


    
});
